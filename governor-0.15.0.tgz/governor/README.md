# Governor

## Description

A repo holding the Kubernetes deployment manifests for the governor ecosystem

[Governor API](https://github.com/metal-toolbox/governor-api)

## Installation

* Add the Equinix Metal helm repository

```bash
helm repo add equinixmetal https://helm.equinixmetal.com
```

* Install the helm chart using default values

```bash
helm install governor-api equinixmetal/governor-api
```

> If you are using your own chart, reference the following to your chart's dependencies:
> ```yaml
> dependencies:
>   - name: governor-api
>     version: v0.0.1
>     repository: "https://helm.equinixmetal.com"
> ```

## Usage

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| api | object | `{"adminGroups":"governor-admins","db":{"connections":{"max_idle":20,"max_lifetime":0,"max_open":20},"secrets":{"crdbCrt":null,"enabled":false,"uri":null},"uri":{"existingSecret":"db-uri"}},"debug":false,"enabled":true,"iamRuntime":{"enabled":false,"socket":"unix:///var/iam-runtime/runtime.sock","timeout":"15s"},"image":{"pullPolicy":"IfNotPresent","repository":"ghcr.io/metal-toolbox/governor-api","tag":"v0.14.0"},"ingress":{"additionalHosts":[],"className":"nginx","host":"api.governor.example.com","prefix":"api.governor"},"labels":{"app.kubernetes.io/component":"api","app.kubernetes.io/instance":"governor","app.kubernetes.io/managed-by":"Helm","app.kubernetes.io/name":"governor"},"matchLabels":{"app.kubernetes.io/instance":"governor","app.kubernetes.io/name":"governor"},"nats":{"authMode":"creds-file-only","credsPath":"/nats","secrets":{"clientCreds":null,"enabled":false},"subjectPrefix":"governor.events","url":null},"oidc":[{"audience":"","enabled":true,"issuer":"","jwksuri":"","rolesClaim":"","userClaim":""}],"readinessProbe":{"failureThreshold":3,"periodSeconds":20,"successThreshold":1,"timeoutSeconds":3},"replicaCount":2,"resources":{"limits":{"cpu":"500m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"128Mi"}},"securityContext":{"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1000},"serviceAccount":{"name":"default"},"serviceAccountToken":{"audience":"","expirationSeconds":null},"tracing":{"enabled":true,"endpoint":"http://opentelemetry-collector:4317","insecure":true,"secrets":{"enabled":false,"honeycombKey":null}},"workloadIdentity":{"audience":"","kubeServiceAccount":"/var/run/secrets/tokens/service-account-token","scopes":[],"subjectTokenType":"urn:ietf:params:oauth:token-type:id_token","tokenURL":""}}` | governor-api settings |
| api.adminGroups | string | `"governor-admins"` | admin group for highest level permissions in the governor-api |
| api.db | object | `{"connections":{"max_idle":20,"max_lifetime":0,"max_open":20},"secrets":{"crdbCrt":null,"enabled":false,"uri":null},"uri":{"existingSecret":"db-uri"}}` | settings for the backend db |
| api.db.secrets | object | `{"crdbCrt":null,"enabled":false,"uri":null}` | db secrets, set to `true` if you want to set the value directly in the chart (not recommended) |
| api.debug | bool | `false` | set to true to turn on debug logging |
| api.enabled | bool | `true` | enable the governor-api components |
| api.iamRuntime.enabled | bool | `false` | enabling IAM runtime will inject iam-runtime-infratographer configs    and sidecars to the deployment |
| api.image | object | `{"pullPolicy":"IfNotPresent","repository":"ghcr.io/metal-toolbox/governor-api","tag":"v0.14.0"}` | image for the governor-api |
| api.image.pullPolicy | string | `"IfNotPresent"` | image pull policy for the governor-api container |
| api.image.repository | string | `"ghcr.io/metal-toolbox/governor-api"` | container image repository for the governor-api image |
| api.image.tag | string | `"v0.14.0"` | image tag version |
| api.ingress | object | `{"additionalHosts":[],"className":"nginx","host":"api.governor.example.com","prefix":"api.governor"}` | ingress settings for the governor-api |
| api.ingress.additionalHosts | list | `[]` | additional hosts for the api ingress |
| api.ingress.className | string | `"nginx"` | ingress class name to use for the governor-api ingress, this should match the class name of your ingress controller |
| api.ingress.host | string | `"api.governor.example.com"` | host definition for the api ingress |
| api.ingress.prefix | string | `"api.governor"` | prefix use for the governor api ingress |
| api.labels | object | `{"app.kubernetes.io/component":"api","app.kubernetes.io/instance":"governor","app.kubernetes.io/managed-by":"Helm","app.kubernetes.io/name":"governor"}` | set of additional labels for the application |
| api.matchLabels | object | `{"app.kubernetes.io/instance":"governor","app.kubernetes.io/name":"governor"}` | set of additional match labels for the application |
| api.nats | object | `{"authMode":"creds-file-only","credsPath":"/nats","secrets":{"clientCreds":null,"enabled":false},"subjectPrefix":"governor.events","url":null}` | nats settings for the governor-api |
| api.nats.authMode | string | `"creds-file-only"` | authMode is the method used to authenticate to NATS, available options are:    - creds-file-only: use the NATS credentials file for authentication    - workload-identity: use Kubernetes workload identity for authentication    - iam-runtime: use the IAM runtime for authentication |
| api.nats.credsPath | string | `"/nats"` | mount path for the nats creds file |
| api.nats.secrets | object | `{"clientCreds":null,"enabled":false}` | nats secrets definitions |
| api.nats.secrets.clientCreds | string | `nil` | client credentials secrets |
| api.nats.secrets.enabled | bool | `false` | enable helm secrets, set to `true` if you want to set the value directly in the chart (not recommended) |
| api.nats.subjectPrefix | string | `"governor.events"` | subject prefix used for the nats events |
| api.nats.url | string | `nil` | url to connection to nats |
| api.oidc | list | `[{"audience":"","enabled":true,"issuer":"","jwksuri":"","rolesClaim":"","userClaim":""}]` | oidc settings, currently startup will fail without a valid oidc config |
| api.oidc[0] | object | `{"audience":"","enabled":true,"issuer":"","jwksuri":"","rolesClaim":"","userClaim":""}` | a unique identifier for your app that is issued to you when you register your app with the IdP |
| api.readinessProbe | object | `{"failureThreshold":3,"periodSeconds":20,"successThreshold":1,"timeoutSeconds":3}` | readiness probe definitions for the governor-api pod |
| api.readinessProbe.failureThreshold | int | `3` | minimum consecutive failures for the probe to be considered unhealthy |
| api.readinessProbe.periodSeconds | int | `20` | interval to run the readiness probe |
| api.readinessProbe.successThreshold | int | `1` | minimum consecutive successes for probe to be considered successful |
| api.readinessProbe.timeoutSeconds | int | `3` | number of seconds to wait for the probe to timeout |
| api.replicaCount | int | `2` | replicas of the governor-api |
| api.resources | object | `{"limits":{"cpu":"500m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"128Mi"}}` | resource settings for the governor-api |
| api.securityContext | object | `{"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1000}` | Security context to be added to the deployment |
| api.serviceAccount | object | `{"name":"default"}` | set service account name for the governor-api |
| api.serviceAccountToken | object | `{"audience":"","expirationSeconds":null}` | projected service account token settings for the `tokens` volume, shared    by the workload-identity and iam-runtime auth paths (both read the token    at `/var/run/secrets/tokens/service-account-token`). Set `audience` to    mint the SA token with a specific `aud` claim (distinct from    `workloadIdentity.audience`, which is the exchange parameter sent to    `tokenURL`). Both fields are optional; when unset the SA token is minted    with the API server's default audience. |
| api.tracing | object | `{"enabled":true,"endpoint":"http://opentelemetry-collector:4317","insecure":true,"secrets":{"enabled":false,"honeycombKey":null}}` | tracing settings |
| api.tracing.endpoint | string | `"http://opentelemetry-collector:4317"` | OpenTelemetry endpoint configuration |
| api.tracing.insecure | bool | `true` | whether to use insecure connection to the OTEL endpoint |
| api.tracing.secrets | object | `{"enabled":false,"honeycombKey":null}` | tracing secrets, set to `true` if you want to set the value directly in the chart (not recommended) |
| api.workloadIdentity | object | `{"audience":"","kubeServiceAccount":"/var/run/secrets/tokens/service-account-token","scopes":[],"subjectTokenType":"urn:ietf:params:oauth:token-type:id_token","tokenURL":""}` | workload identity federation |
| api.workloadIdentity.kubeServiceAccount | string | `"/var/run/secrets/tokens/service-account-token"` | path to kube service account token |
| audit | object | `{"auditImage":{"pullPolicy":"IfNotPresent","repository":"ghcr.io/metal-toolbox/audittail","tag":"v0.9.0"},"initContainer":{"resources":{"limits":{"cpu":"100m","memory":"20Mi"},"requests":{"cpu":"100m","memory":"20Mi"}}},"resources":{"limits":{"cpu":"500m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"128Mi"}},"securityContext":{"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1000}}` | audit sidecar settings |
| cedar | object | `{"bindings":[],"enabled":false,"image":{"pullPolicy":"IfNotPresent","repository":"permitio/cedar-agent","tag":"0.2.2"},"logLevel":"warn","port":8180,"resources":{"limits":{"cpu":"200m","memory":"128Mi"},"requests":{"cpu":"50m","memory":"64Mi"}},"roles":[],"securityContext":{"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1000}}` | cedar-agent external authorization sidecar settings |
| cedar.bindings | list | `[]` | bind JWT subjects (Workload principals) to a role by its `id`. A subject    is the token `sub` claim, e.g. the WIF principal string. |
| cedar.enabled | bool | `false` | deploy the permitio/cedar-agent sidecar alongside governor-api and    generate its schema/policies/data from the roles and bindings below.    Enable per-provider authorization with `api.oidc[].cedar.enabled`. |
| cedar.image | object | `{"pullPolicy":"IfNotPresent","repository":"permitio/cedar-agent","tag":"0.2.2"}` | image settings for the cedar-agent sidecar |
| cedar.image.pullPolicy | string | `"IfNotPresent"` | image pull policy for the cedar-agent container |
| cedar.image.repository | string | `"permitio/cedar-agent"` | container image repository for cedar-agent |
| cedar.image.tag | string | `"0.2.2"` | image tag version (pin explicitly; do not use latest) |
| cedar.logLevel | string | `"warn"` | cedar-agent log level (error, warn, info, debug, trace). Defaults to    `warn` to suppress the per-request and route-dump logging that `info`    emits; raise to `info`/`debug` for troubleshooting. |
| cedar.port | int | `8180` | port cedar-agent listens on. It binds to loopback only and is reachable    by governor-api inside the pod at http://127.0.0.1:<port> |
| cedar.resources | object | `{"limits":{"cpu":"200m","memory":"128Mi"},"requests":{"cpu":"50m","memory":"64Mi"}}` | resource settings for the cedar-agent sidecar |
| cedar.roles | list | `[]` | cedar roles, each rendered as one cedar policy. `id` is the policy id and    the key referenced by bindings; `name` (defaults to `id`) is the Cedar    `Role` entity id used in policies and data. Each entry in `permissions`    must be `<verb>:governor:<resource>` where verb is one of    create/read/update/delete and resource is one of users/groups/    applications/organizations/extensions/extensionresources/notifications/    events. Invalid permissions fail the render. |
| cedar.securityContext | object | `{"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1000}` | Security context to be added to the cedar-agent container |
| iam-runtime-infratographer | object | `{"config":{"accessTokenProvider":{"enabled":false,"exchange":{"issuer":""},"source":{"file":{"tokenPath":"/var/run/secrets/tokens/service-account-token"}}},"jwt":{"issuer":"","jwksURI":""},"permissions":{"disable":true}},"resources":{"limits":{"cpu":1,"memory":"256Mi"},"requests":{"cpu":"100m","memory":"128Mi"}},"securityContext":{"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1000},"volumeMounts":[{"mountPath":"/var/run/secrets/tokens","name":"tokens"}]}` | iam-runtime sidecar settings |
| iam-runtime-infratographer.securityContext | object | `{"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1000}` | Security context to be added to the deployment |
| slackAddon | object | `{"api":{"audience":"https://api.governor.example.com","clientId":"gov-slack-addon-governor","url":"https://api.governor.example.com"},"applicationType":"slack","autoscaling":{"enabled":false},"debug":false,"dryrun":false,"enabled":true,"hydra":{"url":"https://hydra.example.com/oauth2/token"},"iamRuntime":{"enabled":false,"socket":"unix:///var/iam-runtime/runtime.sock","timeout":"15s"},"image":{"pullPolicy":"IfNotPresent","repository":"ghcr.io/metal-toolbox/governor-slack-addon","tag":"463-92d597cb"},"labels":{"app.kubernetes.io/instance":"gov-slack-addon","app.kubernetes.io/managed-by":"Helm","app.kubernetes.io/name":"gov-slack-addon"},"matchLabels":{"app.kubernetes.io/instance":"gov-slack-addon","app.kubernetes.io/name":"gov-slack-addon"},"nats":{"authMode":"creds-file-only","credsPath":"/nats","queueGroup":"gov-slack-addon","queueSize":3,"subjectPrefix":"governor.events","url":"tls://nats.governor.example.com:4222,"},"nodeSelector":null,"ports":[{"containerPort":8000,"name":"http"}],"pretty":false,"reconciler":{"interval":"1h","locking":true},"replicas":1,"resources":{"limits":{"cpu":"500m","memory":"500Mi"},"requests":{"cpu":"250m","memory":"500Mi"}},"securityContext":{"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1000},"service":{"port":80},"serviceAccount":{"name":"default"},"serviceAccountToken":{"audience":"","expirationSeconds":null},"slack":{"usergroupPrefix":"[Governor] "},"tolerations":null,"tracing":{"enabled":false,"endpoint":"http://opentelemetry-collector:4317","insecure":true},"workloadIdentity":{"audience":"","enabled":false,"kubeServiceAccount":"/var/run/secrets/tokens/service-account-token","scopes":[],"subjectTokenType":"urn:ietf:params:oauth:token-type:id_token","tokenURL":""}}` | slack-addon settings |
| slackAddon.api | object | `{"audience":"https://api.governor.example.com","clientId":"gov-slack-addon-governor","url":"https://api.governor.example.com"}` | governor-api settings to retrieve required information by the slack addon |
| slackAddon.applicationType | string | `"slack"` | governor application type slug the addon listens to events for |
| slackAddon.debug | bool | `false` | set to true to turn on debug logging |
| slackAddon.dryrun | bool | `false` | dryrun on the reconcile loop |
| slackAddon.enabled | bool | `true` | set to false to disable this addon completely |
| slackAddon.hydra | object | `{"url":"https://hydra.example.com/oauth2/token"}` | hydra settings for communication with the governor-api |
| slackAddon.iamRuntime | object | `{"enabled":false,"socket":"unix:///var/iam-runtime/runtime.sock","timeout":"15s"}` | IAM runtime settings for the slack addon |
| slackAddon.iamRuntime.enabled | bool | `false` | enabling IAM runtime will inject iam-runtime-infratographer configs    and sidecars to the deployment |
| slackAddon.image | object | `{"pullPolicy":"IfNotPresent","repository":"ghcr.io/metal-toolbox/governor-slack-addon","tag":"463-92d597cb"}` | image settings for the slack addon |
| slackAddon.labels | object | `{"app.kubernetes.io/instance":"gov-slack-addon","app.kubernetes.io/managed-by":"Helm","app.kubernetes.io/name":"gov-slack-addon"}` | set of labels for the application |
| slackAddon.matchLabels | object | `{"app.kubernetes.io/instance":"gov-slack-addon","app.kubernetes.io/name":"gov-slack-addon"}` | set of match labels for the application |
| slackAddon.nats | object | `{"authMode":"creds-file-only","credsPath":"/nats","queueGroup":"gov-slack-addon","queueSize":3,"subjectPrefix":"governor.events","url":"tls://nats.governor.example.com:4222,"}` | nats setup for the slack addon |
| slackAddon.nats.queueGroup | string | `"gov-slack-addon"` | queue group for load balancing events across addon replicas/subscriptions.    MUST be non-empty: with an empty group and queueSize > 1 every event is    fanned out to each subscription and processed multiple times. |
| slackAddon.nats.queueSize | int | `3` | number of concurrent subscriptions (workers) sharing the queue group |
| slackAddon.ports | list | `[{"containerPort":8000,"name":"http"}]` | ports for the slack addon container |
| slackAddon.pretty | bool | `false` | set to true for human readable logging |
| slackAddon.resources | dict | `{"limits":{"cpu":"500m","memory":"500Mi"},"requests":{"cpu":"250m","memory":"500Mi"}}` | resource limits & requests ref: https://kubernetes.io/docs/user-guide/compute-resources/ |
| slackAddon.securityContext | object | `{"capabilities":{"drop":["ALL"]},"readOnlyRootFilesystem":true,"runAsNonRoot":true,"runAsUser":1000}` | Security context to be added to the deployment |
| slackAddon.serviceAccount | object | `{"name":"default"}` | set service account name for the slack addon |
| slackAddon.serviceAccountToken | object | `{"audience":"","expirationSeconds":null}` | projected service account token settings for the `tokens` volume used by    the workload-identity (and iam-runtime) auth paths. Set `audience` to mint    the SA token with a specific `aud` claim (this is the token audience, which    is distinct from `workloadIdentity.audience`, the exchange    parameter sent to `tokenURL`). Both fields are optional. |
| slackAddon.slack | object | `{"usergroupPrefix":"[Governor] "}` | slack api settings |
| slackAddon.slack.usergroupPrefix | string | `"[Governor] "` | prefix prepended to slack usergroup names created by the addon.    the slack api token is provided via the gov-slack-addon-creds secret. |
| slackAddon.tracing | object | `{"enabled":false,"endpoint":"http://opentelemetry-collector:4317","insecure":true}` | tracing settings for the slack addon |
| slackAddon.tracing.endpoint | string | `"http://opentelemetry-collector:4317"` | OpenTelemetry endpoint configuration |
| slackAddon.tracing.insecure | bool | `true` | whether to use insecure connection to the OTEL endpoint |
| slackAddon.workloadIdentity | object | `{"audience":"","enabled":false,"kubeServiceAccount":"/var/run/secrets/tokens/service-account-token","scopes":[],"subjectTokenType":"urn:ietf:params:oauth:token-type:id_token","tokenURL":""}` | workload identity federation settings for the slack addon. When enabled,    the addon authenticates to governor by exchanging its projected kube    service account token (mounted from the `tokens` volume) at `tokenURL`,    instead of using the hydra client-credentials flow. |

## Development

### Prerequisites

- [helm](https://helm.sh/docs/intro/install/)
- [helm-docs](https://github.com/norwoodj/helm-docs)

### Testing

Ensure that the documentation is up to date before pushing a pull request:

```bash
helm-docs
```

### Releasing

There is a useful Makefile target that's useful to cut a release. So, simply do:

```bash
TAG=$RELEASE_VERSION make release
```

And the release will happen.

Note that this project follows the [Semantic Versioning scheme](https://semver.org/), so
make sure to follow it when cutting releases.

The `TAG` Makefile variable takes a release version without the `v` prefix. For example,
if you want to cut a release with version `v1.2.3`, you'd do:

```bash
TAG=1.2.3 make release
```
